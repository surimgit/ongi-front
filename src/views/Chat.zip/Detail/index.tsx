import React from "react";
import "./style.css";

interface Props {
  chatTitle: string;
}

export default function ChatDetail({ chatTitle }: Props) {
  return (
    <div className="chat-detail-wrapper">
      <div className="chat-detail-header">
        <div className="chat-detail-info">
          <div className="chat-detail-title">{chatTitle}</div>
          <div className="chat-detail-subtitle">온기</div>
        </div>
      </div>
      <div className="chat-detail-body">
        <div className="chat-product">
          <div className="chat-product-info">
            <div className="chat-product-title">바퀴벌레 잡아주세요</div>
            <div className="chat-product-price">
              <span className="chat-product-price">20,000원</span>
            </div>
          </div>
          <button className="chat-product-button">글 보기</button>
        </div>
        <div className="chat-messages">{/* 채팅 메시지 표시할 부분 */}</div>
        <div className="chat-input-area">
          <input
            type="text"
            className="chat-input"
            placeholder="메시지를 입력하세요."
          />
          <button className="chat-send-button">전송</button>
        </div>
      </div>
    </div>
  );
}
